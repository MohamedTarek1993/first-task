(function ($) {

    'use strict';

    // ajax goes here....

    let load_more_container = $('.load-more-content');

    $(window).scroll(function () {
        // detect if div is visible ".load-more-point"
        if ($('.load-more-point').is(':visible')) {
            let post_id = $('.load-more-point').data('post-id');
            $(document).trigger('reach-load-more-div', [post_id]);
        }
    });

    $(document).on('reach-load-more-div', function (e, post_id) {
        $.ajax({
            url: loadMore.ajax_url,
            type: 'post',
            data: {
                action: 'my_load_more_function',
                post_id: post_id
            },
            success: function (response) {
                if(response.success) {
                    //success
                    let data = response.data,
                        html = `<img src="${data.image_url}">
                                <h2><a href="${data.link}">${data.title}</a></h2>`;
                    load_more_container.append(html);
                    //update url
                    history.pushState(null, data.title, data.link);
                    $('.load-more-point').data('post-id',data.id);
                }else{
                    //fail
                }
            }
        });
    });

})(jQuery);